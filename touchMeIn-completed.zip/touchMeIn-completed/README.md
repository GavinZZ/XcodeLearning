# TouchMeIn: A tutorial for exploring Keychain, Touch ID and 1Password Integration.

Mar 2017: Updated for Swift 3.1

Aug 2016: Updated for Swift 2.2

Dec 2014: Original Tutorial

Copyright (C) 2017 Razeware LLC. All rights reserved.
